// valid example of api call "http://www.omdbapi.com/?apikey=4d460387&t=batman"

import { Component } from "@angular/core";
import { HttpParams } from "@angular/common/http";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  constructor() {}

  private searchterm: string;
  private params: HttpParams;
  public api = "http://www.omdbapi.com/";
  private apiKey = "4d460387";
  private url = this.api + "?" + "apikey" + "=" + this.apiKey + "&";
  utilityMethod() {
    this.params = new HttpParams()
      .set("t", this.searchterm)
    console.log(this.api + this.params);
  }
}
