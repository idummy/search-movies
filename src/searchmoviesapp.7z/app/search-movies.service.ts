import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
import "rxjs/add/operator/map";
import { Observable } from "rxjs/Observable";

@Injectable()
export class SearchMoviesService {
  constructor(private http: Http) {}

  public baseUrl = "http://www.omdbapi.com/";

  search(url: string) {
    this.http.get(url).map(res => res.json)
  }
}
